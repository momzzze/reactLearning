exports.PORT = 3000;
exports.DB_QUERYSTRING = 'mongodb://localhost:27017/cryptoTrade';
exports.SALT_ROUNDS=10;
exports.SECRET='dsadasadsagf97s69dhjaos866d86as5dhnlas';
